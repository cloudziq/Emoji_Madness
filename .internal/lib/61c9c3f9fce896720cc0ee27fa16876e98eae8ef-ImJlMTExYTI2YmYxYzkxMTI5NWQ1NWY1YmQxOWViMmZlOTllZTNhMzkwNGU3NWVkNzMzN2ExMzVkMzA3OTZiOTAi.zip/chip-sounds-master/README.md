# Chip Sounds

A collection of lowfi retro like sound effects made ready for Defold (with care to not make your ears bleed)

Have some sounds you've produced and own the rights to which you would like to contribute? Send to me!